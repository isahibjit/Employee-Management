// src/App.jsx
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import Login from '../Pages/Login';
import Employees from '../Pages/Employees';
import ProtectedLayout from './Layouts';

const router = createBrowserRouter([
  {
    path: '/',
    element: <Login />
  },
  {
    path: '/employees',
    element: <ProtectedLayout />,
    children: [
      {
        index: true,
        element: <Employees />
      }
    ]
  }
]);

function App() {
  return <RouterProvider router={router} />;
}

export default App;
