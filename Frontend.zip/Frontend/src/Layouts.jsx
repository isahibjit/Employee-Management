
import { Navigate, Outlet } from 'react-router-dom';
import { useEffect, useState } from 'react';
import Cookies from 'js-cookie';
import Navbar from '../Components/Navbar';

const ProtectedLayout = () => {
  const token = Cookies.get('token')
    console.log(token)
  if (!token) {
    return <Navigate to="/" />;
  }

  return (
    <div className="p-4">
      <Outlet />
    </div>
  );
};

export default ProtectedLayout;
