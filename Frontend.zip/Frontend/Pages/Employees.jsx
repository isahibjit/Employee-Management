import React, { useEffect, useState } from "react";
import api from "../src/lib/axiosInstance";

const initialForm = {
  name: "",
  email: "",
  department: "",
  position: "",
  joinDate: "",
  skills: "",
};

const Employees = () => {
  const [employees, setEmployees] = useState([]);
  const [formData, setFormData] = useState(initialForm);
  const [imageFile, setImageFile] = useState(null);
  const [editingId, setEditingId] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchEmployees();
  }, []);

  const fetchEmployees = async () => {
    try {
      const res = await api.get("/employees");
      setEmployees(res.data.employees || []);
    } catch (err) {
      console.error("Failed to fetch employees", err);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this employee?"))
      return;
    try {
      await api.delete(`/employees/${id}`);
      fetchEmployees();
    } catch (err) {
      console.error("Failed to delete employee", err);
    }
  };

  const handleSearch = async () => {
    try {
      const res = await api.get(`/employees/search?q=${searchQuery}`);
      setEmployees(res.data.employees || res.data || []);
    } catch (err) {
      console.error("Error searching employees:", err);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((f) => ({ ...f, [name]: value }));
  };

  const handleImageChange = (e) => {
    setImageFile(e.target.files[0]);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const payload = {
      ...formData,
      skills: formData.skills.split(",").map((s) => s.trim()),
    };

    try {
      let employeeId;

      if (editingId) {
        await api.put(`/employees/${editingId}`, payload);
        employeeId = editingId;
      } else {
        const res = await api.post("/employees", payload);
        employeeId = res.data._id;
      }

      if (imageFile && employeeId) {
        const imgForm = new FormData();
        imgForm.append("profileImage", imageFile);
        await api.post(`/employees/${employeeId}/upload`, imgForm, {
          headers: { "Content-Type": "multipart/form-data" },
        });
      }

      setFormData(initialForm);
      setImageFile(null);
      setEditingId(null);
      fetchEmployees();
    } catch (err) {
      console.error("Failed to save employee", err);
    }
  };

  const handleEdit = (emp) => {
    setFormData({
      name: emp.name,
      email: emp.email,
      department: emp.department || "",
      position: emp.position,
      joinDate: emp.joinDate.split("T")[0],
      skills: emp.skills?.join(", "),
    });
    setEditingId(emp._id);
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setFormData(initialForm);
    setImageFile(null);
  };

  return (
    <div className="min-h-screen p-8 bg-gray-100">
      <h2 className="text-3xl font-bold mb-6 text-gray-700">
        Employee Management
      </h2>

      {/* Form */}
      <form
        onSubmit={handleSubmit}
        className="bg-white p-6 rounded-lg shadow mb-8 grid grid-cols-1 md:grid-cols-3 gap-4"
      >
        <input
          name="name"
          value={formData.name}
          onChange={handleChange}
          placeholder="Name"
          required
          className="border p-2 rounded-md"
        />
        <input
          name="email"
          value={formData.email}
          onChange={handleChange}
          placeholder="Email"
          required
          className="border p-2 rounded-md"
        />
        <select
          name="department"
          value={formData.department}
          onChange={handleChange}
          required
          className="border p-2 rounded-md"
        >
          <option value="">Select Department</option>
          <option value="6880bb86ebd9d8dbe5216b73">Tech</option>
          <option value="6880be3aebd9d8dbe5216b74">Non-Tech</option>
        </select>

        <input
          name="position"
          value={formData.position}
          onChange={handleChange}
          placeholder="Position"
          className="border p-2 rounded-md"
        />
        <input
          name="joinDate"
          type="date"
          value={formData.joinDate}
          onChange={handleChange}
          required
          className="border p-2 rounded-md"
        />
        <input
          name="skills"
          value={formData.skills}
          onChange={handleChange}
          placeholder="Skills (comma separated)"
          className="border p-2 rounded-md"
        />
        <input
          type="file"
          onChange={handleImageChange}
          accept="image/*"
          className="col-span-full border p-2 rounded-md"
        />

        <div className="col-span-full flex gap-3 mt-2">
          <button
            type="submit"
            className="bg-green-600 hover:bg-green-700 text-white px-5 py-2 rounded transition"
          >
            {editingId ? "Update" : "Add"} Employee
          </button>
          {editingId && (
            <button
              onClick={handleCancelEdit}
              type="button"
              className="bg-gray-500 hover:bg-gray-600 text-white px-5 py-2 rounded transition"
            >
              Cancel
            </button>
          )}
        </div>
      </form>

      {/* Search */}
      <div className="flex mb-6 gap-2">
        <input
          type="text"
          placeholder="Search by name or email"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="border px-3 py-2 rounded w-full max-w-sm"
        />
        <button
          onClick={handleSearch}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded transition"
        >
          Search
        </button>
      </div>

      {/* Table */}
      {loading ? (
        <p>Loading employees...</p>
      ) : employees.length === 0 ? (
        <p>No employees found.</p>
      ) : (
        <div className="overflow-x-auto rounded shadow">
          <table className="min-w-full bg-white">
            <thead className="bg-gray-200 text-gray-600 uppercase text-sm">
              <tr>
                <th className="text-left px-4 py-2">Name</th>
                <th className="text-left px-4 py-2">Email</th>
                <th className="text-left px-4 py-2">Department</th>
                <th className="text-left px-4 py-2">Position</th>
                <th className="text-left px-4 py-2">Join Date</th>
                <th className="text-left px-4 py-2">Skills</th>
                <th className="text-left px-4 py-2">Image</th>
                <th className="text-left px-4 py-2">Actions</th>
              </tr>
            </thead>
            <tbody className="text-gray-700">
              {employees.map((emp, idx) => (
                <tr
                  key={emp._id}
                  className={idx % 2 === 0 ? "bg-white" : "bg-gray-50"}
                >
                  <td className="px-4 py-2">{emp.name}</td>
                  <td className="px-4 py-2">{emp.email}</td>
                  <td className="px-4 py-2">
                    {emp.department?.name || emp.department || "N/A"}
                  </td>
                  <td className="px-4 py-2">{emp.position}</td>
                  <td className="px-4 py-2">
                    {new Date(emp.joinDate).toLocaleDateString()}
                  </td>
                  <td className="px-4 py-2">{emp.skills?.join(", ")}</td>
                  <td className="px-4 py-2">
                    {emp.profileImage ? (
                      <img
                        src={`http://localhost:8080${emp.profileImage}`}
                        alt="Profile"
                        className="w-10 h-10 rounded-full object-cover"
                      />
                    ) : (
                      <div className="w-10 h-10 rounded-full bg-gray-300 flex items-center justify-center text-xs text-white">
                        N/A
                      </div>
                    )}
                  </td>
                  <td className="px-4 py-2 space-x-2">
                    <button
                      onClick={() => handleEdit(emp)}
                      className="bg-yellow-400 hover:bg-yellow-500 text-white px-3 py-1 rounded text-sm"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => handleDelete(emp._id)}
                      className="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded text-sm"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default Employees;
