import { Router } from "express";
import {
  addEmployee,
  addImage,
  getAllEmployees,
  getEmployeeByQuery,
  updateEmployeeById,
} from "../Controller/Employee.controller.js";
import upload from "../middleware/multer.js"
import authMiddleware from "../middleware/auth.js";
import validateEmployee from "../middleware/validateEmployee.js";
const router = Router();
import '../models/Department.models.js'; 

router.post("/employees",authMiddleware,validateEmployee, addEmployee);

router.get("/employees",authMiddleware, getAllEmployees);

router.get("/employees/search",authMiddleware, getEmployeeByQuery);

router.put("/employees/:id",authMiddleware, updateEmployeeById);

router.post("/employees/:id/upload",authMiddleware, upload.single("profileImage"), addImage);
export default router;
