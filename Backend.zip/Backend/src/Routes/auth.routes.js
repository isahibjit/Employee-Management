import express from 'express';
import jwt from "jsonwebtoken"
import dotenv from "dotenv"
const router = express.Router();
dotenv.config()
const adminUser = {
  email: 'admin@example.com',
  password: 'admin123',
  name: 'Admin'
};
const JWT_SECRET = process.env.JWT_SECRET || "aimbeat"
router.post('/login', (req, res) => {
  const { email, password } = req.body;

  if (email === adminUser.email && password === adminUser.password) {
    const token = jwt.sign({ email: adminUser.email, name: adminUser.name }, JWT_SECRET, { expiresIn: '1h' });

    res.cookie('token', token, {
      httpOnly: false,
      secure: false, 
      maxAge: 3600000
    });

    return res.status(200).json({ message: 'Login successful' });
  }

  res.status(401).json({ error: 'Invalid credentials' });
});

router.post('/logout', (req, res) => {
  res.clearCookie('token').json({ message: 'Logged out successfully' });
});

export default router;
