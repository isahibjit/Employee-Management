import Employee from "../models/Employee.models.js";


export const getAllEmployees = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;

    const skip = (page - 1) * limit;
    const employees = await Employee.find()
      .populate('department')
      .skip(skip)
      .limit(limit);

    const total = await Employee.countDocuments();
    res.json({
      total,
      page,
      totalPages: Math.ceil(total / limit),
      employees
    });
  } catch (err) {
    console.log(err)
    res.status(500).json({ error: 'Failed to fetch employees' });
  }
};

export const addEmployee = async (req, res) => {
  try {
    const { name, email, department, position, joinDate, skills } = req.body;
    console.log(req.body)
    const parsedSkills = Array.isArray(skills)
      ? skills
      : typeof skills === 'string'
        ? skills.split(',').map(s => s.trim())
        : [];

    const newEmployee = new Employee({
      name,
      email,
      department,
      position,
      joinDate,
      skills: parsedSkills
    });

    const savedEmployee = await newEmployee.save();
    res.status(201).json(savedEmployee);
  } catch (err) {
    console.log(err)
    res.status(500).json({ error: 'Failed to add employee', details: err.message });
  }
};


export const getEmployeeByQuery = async (req, res) => {
  const search = req.query.q;

  if (!search) {
    return res.status(400).json({ error: 'Missing search query (q)' });
  }

  try {
    const regex = new RegExp(search, 'i'); // case-insensitive search

    const employees = await Employee.find({
      $or: [
        { name: regex },
        { email: regex }
      ]
    }).populate('department');

    if (employees.length === 0) {
      return res.status(404).json({ error: 'No matching employees found' });
    }

    res.json(employees);
  } catch (err) {
    console.error('Search error:', err);
    res.status(500).json({ error: 'Error searching employees' });
  }
};




export const updateEmployeeById = async (req, res) => {
  const id = req.params.id;
  try {
    const updatedData = { ...req.body };

    // Remove department if it's an empty string
    if (updatedData.department === '') {
      delete updatedData.department;
    }

    const employee = await Employee.findByIdAndUpdate(id, updatedData, { new: true });

    if (!employee) return res.status(404).json({ error: 'Employee not found' });

    res.json(employee);
  } catch (err) {
    console.log(err);
    res.status(500).json({ error: 'Failed to update employee' });
  }
};


export const addImage = async (req, res) => {
  const id = req.params.id;
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const imagePath = `/uploads/${req.file.filename}`;
    const employee = await Employee.findByIdAndUpdate(id, { profileImage: imagePath }, { new: true });

    if (!employee) return res.status(404).json({ error: 'Employee not found' });

    res.json({ message: 'Image uploaded successfully', employee });
  } catch (err) {
    res.status(500).json({ error: 'Failed to upload image' });
  }
};
