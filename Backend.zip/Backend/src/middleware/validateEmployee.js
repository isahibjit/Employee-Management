// middleware/validateEmployee.js
import mongoose from 'mongoose';

const validateEmployee = (req, res, next) => {
  const { name, email, department, position, joinDate, skills, profileImage } = req.body;

  if (!name || typeof name !== 'string') {
    return res.status(400).json({ error: 'Name is required and must be a string' });
  }

  if (!email || typeof email !== 'string' || !email.includes('@')) {
    return res.status(400).json({ error: 'Valid email is required' });
  }

  if (!department || !mongoose.Types.ObjectId.isValid(department)) {
    return res.status(400).json({ error: 'Valid department ID is required' });
  }

  if (!position || typeof position !== 'string') {
    return res.status(400).json({ error: 'Position is required and must be a string' });
  }

  if (!joinDate || isNaN(new Date(joinDate))) {
    return res.status(400).json({ error: 'Valid join date is required' });
  }

  if (skills && !Array.isArray(skills)) {
    return res.status(400).json({ error: 'Skills must be an array' });
  }

  if (profileImage && typeof profileImage !== 'string') {
    return res.status(400).json({ error: 'Profile image must be a string (URL)' });
  }

  next(); // All validations passed
};

export default validateEmployee;
