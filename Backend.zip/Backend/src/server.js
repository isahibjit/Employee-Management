import Express from "express";
import dotenv from "dotenv";
import dbInit from "./utils/db.js";
import employeesRoutes from "./Routes/Employees.routes.js";
import authRoutes from "./Routes/auth.routes.js"
import cookieParser from 'cookie-parser';
import cors from "cors"
import morgan from "morgan";

dotenv.config();
const app = Express();


app.use(cors({
  origin: "http://localhost:5173", 
  credentials: true 
}));
app.use(cookieParser()); 
app.use(Express.json());
app.use(morgan("dev"))
app.use('/uploads', Express.static('uploads'));


app.use('/api', employeesRoutes);
app.use('/api',authRoutes)
app.get("/", (req, res) => {
  res.send("working!");
});


dbInit().then(() => {
  app.listen(process.env.PORT || 5000, () => {
    console.log(`Server is running at port ${process.env.PORT || 5000}`);
  });
});
